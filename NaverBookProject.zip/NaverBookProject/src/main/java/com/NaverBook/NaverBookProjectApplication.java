package com.NaverBook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaverBookProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaverBookProjectApplication.class, args);
	}

}
