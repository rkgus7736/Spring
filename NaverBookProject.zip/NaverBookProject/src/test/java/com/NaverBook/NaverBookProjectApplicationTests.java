package com.NaverBook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaverBookProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
