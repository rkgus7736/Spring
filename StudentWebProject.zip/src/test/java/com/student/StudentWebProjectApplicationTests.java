package com.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentWebProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
