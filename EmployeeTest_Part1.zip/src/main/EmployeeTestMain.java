package main;

import java.util.ArrayList;

import dao.EmployeeDAO;
import dto.EmployeeDTO;
import service.EmployeeService;

public class EmployeeTestMain {
	public static void main(String[] args) {
		String result = EmployeeDAO.getInstance().login(sabun);
		System.out.println(result);
		System.out.println("---------------------");
		String result = EmployeeDAO.getInstance().selectAllEmployee();
		System.out.println(result);
		System.out.println("---------------------");
	}
	
	EmployeeDTO dto = EmployeeService.getInstance().login(sabun,name);
}
