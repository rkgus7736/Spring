

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.swing.JOptionPane;

import org.json.JSONArray;
import org.json.JSONObject;

public class NaverSearchMain {

	public static void main(String[] args) {
			String txt = JOptionPane.showInputDialog("블로그 검색어 입력");
			String clientId = "PD_ovGcoK3dWZtuqWYq0";
			String clientSecret = "NKKyAlKUYK";

			try {
				txt = URLEncoder.encode(txt, "utf-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			String apiURL = "https://openapi.naver.com/v1/search/blog?query="+txt+"&sort=date";
			URL url;
			try {
				url = new URL(apiURL);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				con.setRequestProperty("X-Naver-Client-Id", clientId);
				con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
				BufferedReader br;
				int responseCode = con.getResponseCode();
				if (responseCode == 200) { 
					br = new BufferedReader(new InputStreamReader(con.getInputStream()));
				} else { 
					System.out.println(responseCode);
					br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
				}
				String result = "";
				while(true) {
					String str = br.readLine();
					if(str==null)break;
					result += str;
				}
				System.out.println(result);
				JSONObject json = new JSONObject(result);
				JSONArray arr = new JSONArray(json.getJSONArray("items"));
				for(int i=0;i<arr.length();i++) {
					System.out.println(arr.getJSONObject(i).getString("title"));
					System.out.println(arr.getJSONObject(i).getString("link"));
					System.out.println(arr.getJSONObject(i).getString("bloggername"));
				}
					
				br.close();
				con.disconnect();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	
	public static void recordInfo(String url,String blog_search) {
			try {
				URL BlogUrl = new URL(url);
				URLConnection conn = BlogUrl.openConnection(); 
				InputStream is = conn.getInputStream();
				FileOutputStream fos = new FileOutputStream(blog_search + ".txt");
				byte[] arr = new byte[1024];
				while(true) {
					int count = is.read(arr);
					if(count == -1) break; 
					fos.write(arr,0,count);
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		

	}
