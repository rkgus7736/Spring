수정 내역을 작성하시오.
1. application.properties에 있는 OracleDriver -> e 추가
2. book-mapper.xml의 insert sql문 수정
3. book_insert.jsp의 ajax data str -> r로 변경
4. BookMapper의 @Mapper 어노테이션 추가
5. BookWebProjectApplicationTests 클래스에 @RunWith(SpringRunner.class) 추가
